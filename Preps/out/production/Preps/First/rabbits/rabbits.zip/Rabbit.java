package First.rabbits;
public class Rabbit {
    private String name;
    private String species;
    private boolean available = true;

    public Rabbit(String name, String species) {
        this.name = name;
        this.species = species;
    }

    public String getName() {
        return name;
    }

    public String getSpecies() {
        return species;
    }

    public void setAvailable() {
        this.available = false;
    }

    public boolean isAvailable() {
        return available;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(String.format("Rabbit (%s): %s", this.getSpecies(), this.getName()));
        return stringBuilder.toString();
    }
}
